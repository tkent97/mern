import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Hello dojo</h1>
      <h3>Things i need to do :</h3>
      <li>learn react</li>
      <li>climb Mt. Everest</li>
      <li>Run a Marathon</li>
      <li>feed the dogs</li>
    </div>
  );
}

export default App;
