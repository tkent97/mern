import React, { useEffect, useState, useHistory } from 'react'
import axios from 'axios';
import { Link } from 'react-router-dom'

const Main = () => {
    const [title, setTitle] = useState("");
    const [price, setPrice] = useState("");
    const [description, setDescription] = useState("");


    const onSubmitHandler = (e) => {
        e.preventDefault();
        const newProduct = {
            title: title,
            price: price,
            description: description
        }
        axios.post('http://localhost:8000/api/products', newProduct)
            .then(res => console.log(res.data))
            .catch(err => console.log(err))
    }

    return (
        <div>
            <h1>Product Manager</h1>
            <form onSubmit={onSubmitHandler}>
                <label>Title</label>
                <input type="text" onChange={(e) => setTitle(e.target.value)} value={title}></input>
                <label>Price</label>
                <input type="text" onChange={(e) => setPrice(e.target.value)} value={price}></input>
                <label>Description</label>
                <input type="text" onChange={(e) => setDescription(e.target.value)} value={description}></input>
                <button type="submit">create</button>
            </form>
        </div>
    )
}
export default Main