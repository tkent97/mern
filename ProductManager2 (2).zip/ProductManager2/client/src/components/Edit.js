import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { Link } from 'react-router-dom'

const Edit = () => {
    return (
        <div>
            <h1>edit</h1>
        </div>
    )
}
export default Edit